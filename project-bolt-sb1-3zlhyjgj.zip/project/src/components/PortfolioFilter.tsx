import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import clsx from 'clsx';

type Category = 'all' | 'ux-ui' | 'photography' | 'videography' | 'graphic-design';

const categories = [
  { id: 'all', label: 'All Work' },
  { id: 'ux-ui', label: 'UX/UI Design' },
  { id: 'photography', label: 'Photography' },
  { id: 'videography', label: 'Videography' },
  { id: 'graphic-design', label: 'Graphic Design' },
] as const;

export function PortfolioFilter({ onFilterChange }: { onFilterChange: (category: Category) => void }) {
  const [activeCategory, setActiveCategory] = useState<Category>('all');

  const handleCategoryChange = (category: Category) => {
    setActiveCategory(category);
    onFilterChange(category);
  };

  return (
    <div className="flex flex-wrap justify-center gap-4 mb-12">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => handleCategoryChange(category.id as Category)}
          className={clsx(
            'px-6 py-2 rounded-full transition-all duration-300',
            'border-2 hover:border-accent',
            activeCategory === category.id
              ? 'bg-secondary text-white border-secondary'
              : 'bg-transparent text-secondary border-secondary/20'
          )}
        >
          {category.label}
        </button>
      ))}
    </div>
  );
}